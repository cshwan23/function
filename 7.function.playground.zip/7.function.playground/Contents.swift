import UIKit


//Function 함수

/* 기본 구조 :
func 함수이름(함수이름에 대한 내용) {
 어떻게 도출할 것인가
 
 }


*/

//Function 리턴타입도 없고 파라미터 타입도 없는것

func sayHello(){
    print("Hello")
}

sayHello()    //<-- 기능 호출하는법 함수명()


// 파라미터가 있는 거 아규먼트 레이블
func sayHello2(name:String){
    print("Hello \(name)")
}

sayHello2(name: "Choi")


// return type이 있는 function " -> "

func sayHello3(name:String) -> String {
    return "Hello " + name
}
print(sayHello3(name: "Choi"))




//deault value 가 들어가있는 함수

func sayHello4(name:String = "Park"){
    print("Hello \(name)")
}
sayHello4()
sayHello4(name: "Kim")



// argument & parameter 둘다 들어가 있는 함수

func sayHello5(insertYourName name:String,internationlAge age:Int){
    print("Hello \(name) is \(age) years old.")
    
}

sayHello5(insertYourName: "Choi", internationlAge: 10)



// 외우기 힘들다 심플하게 쓰고 싶다 언더스코어 _를 쓰고싶다. 아규멘트를 원하지 않는다.

func sayHello6(_ name:String, _ age:Int) -> String{
    return "\(name) is \(age) years old."
}

print(sayHello6("Choi", 20))





